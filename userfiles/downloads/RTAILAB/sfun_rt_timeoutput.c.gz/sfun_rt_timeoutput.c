#define S_FUNCTION_NAME  sfun_rt_timeoutput
#define S_FUNCTION_LEVEL 2

#include "simstruc.h"

#ifndef MATLAB_MEX_FILE
#ifndef KEEP_STATIC_INLINE
#define KEEP_STATIC_INLINE
#endif

#include <linux/errno.h>
#include <rtai_lxrt_user.h>
#include <rtai_lxrt.h>
#endif

/*--------------------------------------
| FUNZIONI DELLA S-FUNCTION |
----------------------------------------*/
static void mdlInitializeSizes(SimStruct *S)
{

 ssSetNumSFcnParams(S, 1);  /* Number of expected parameters */
 if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
  return;
     }
     ssSetNumContStates(    S, 0);
 ssSetNumDiscStates(    S, 0);
 if (!ssSetNumInputPorts(S, 0)) return;
     if (!ssSetNumOutputPorts(S, 1)) return;

     ssSetOutputPortWidth(S, 0, 1);

 ssSetNumSampleTimes(   S, 1);

 ssSetNumModes(S, 0);
 ssSetNumNonsampledZCs( S, 0);

 //ssSetOptions(S, SS_OPTION_EXCEPTION_FREE_CODE);
 //ssSetOptions(S, SS_OPTION_RUNTIME_EXCEPTION_FREE_CODE);

} /* end mdlInitializeSizes */


static void mdlInitializeSampleTimes(SimStruct *S)
{
 ssSetSampleTime(S, 0, mxGetScalar(ssGetSFcnParam(S, 0)));
 ssSetOffsetTime(S, 0, 0.0);
} /* end mdlInitializeSampleTimes */

#undef MDL_START
#if defined(MDL_START)
static void mdlStart(SimStruct *S){

}
#endif

/* Function: mdlOutputs
=======================================================
 * Abstract:
 *    In this function, you compute the outputs of your S-function
 *    block. Generally outputs are placed in the output vector(s),
 *    ssGetOutputPortSignal.
 */
static void mdlOutputs(SimStruct *S, int_T tid)
{
 #ifndef MATLAB_MEX_FILE //--------------------
   RTIME now;
   #endif   //^^^^^^^^^^^^^^^^^^^^

   real_T *y;
   y = ssGetOutputPortRealSignal(S,0); // y punta ora alle uscite del
blocchetto.

 #ifndef MATLAB_MEX_FILE //--------------------
   now = rt_get_cpu_time_ns();
 y[0] = (real_T) now;
 #endif   //^^^^^^^^^^^^^^^^^^^^
} /* end mdlOutputs */

static void mdlTerminate(SimStruct *S)
{

}  /* end mdlTerminate */

/*=============================*
 * Required S-function trailer *
 *=============================*/

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif 

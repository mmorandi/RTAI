*******************************************************************************

Real-Time Application Interface (version 3.7) for MCF5329

RTAI_readme.txt
COPYRIGHT 2009 FREESCALE SEMICONDUCTOR, INC., ALL RIGHTS RESERVED

*******************************************************************************

  FREESCALE SEMICONDUCTOR, INC.
  ALL RIGHTS RESERVED
  (c) Copyright 2009 Freescale Semiconductor, Inc.

*******************************************************************************

  PURPOSE:   Provides hard real-time scheduling functionality under
		uClinux on the MCF5329 processor

  AUTHORS: 	Oleksandr Marchenko	(Group Leader)
		Valentin Pavlyuchenko	(Project Leader)
		Mykola Lysenko 		(Lead Developer)

*******************************************************************************

This document contains information about the product.
The notes presented are the latest available.

The following topics are covered:

1. RTAI for MCF5329 project overview
2. Requirements
3. Installation
4. Support Information
5. Current project status
6. What's New
7. Troubleshooting
8. Last minute notes

*******************************************************************************
1. RTAI for MCF5329 project overview
*******************************************************************************

The Real-Time Application Interface (RTAI) is a set of extensions for the Linux
operating system that adds support for hard real-time scheduling for processes.
It is a real-time platform which allows for high predictability and low 
latency.

This project aims to implement support for RTAI (version 3.7) on the MCF5329 
microcontroller. The work will consist of adding the architecture support code 
to RTAI as well as making the necessary changes to uClinux to enable RTAI 
support on the ColdFire architecture. 

*******************************************************************************
2. Requirements
*******************************************************************************

MCF5329 evaluation board;
x86 compatible computer;
Linux operating system on the x86 computer.

*******************************************************************************
3. Installation
*******************************************************************************

See README.txt

*******************************************************************************
4. Testing RTAI
*******************************************************************************

RTAI Testsuite includes 6 tests:
1) Kernel-space tests:
   a) "latency"
   b) "switches"
   c) "preempt"
2) User-space tests:
   a) "latency"
   b) "switches"
   c) "preempt"

Testsuite has the following files:
.
|-- modules
|   |-- latency_rt.ko
|   |-- preempt_rt.ko
|   `-- switches_rt.ko
`-- testsuite
    |-- kern
    |   |-- latency
    |   |   |-- display
    |   |   `-- README
    |   |-- preempt
    |   |   |-- display
    |   |   `-- README
    |   `-- switches
    |       `-- README
    `-- user
        |-- latency
        |   |-- latency
        |   |-- display
        |   `-- README
        |-- preempt
        |   |-- preempt
        |   |-- display
        |   `-- README
        `-- switches
            |-- switches
            `-- README

To launch tests:

Run uClinux on the board.
When Sash console will appear, type:

$ cd modules
$ insmod rtai_hal.ko
$ insmod rtai_sched.ko
$ insmod rtai_sem.ko
$ insmod rtai_fifos.ko
$ insmod rtai_mbx.ko
$ insmod rtai_msg.ko
$ cd ../testsuite

To run the kernel tests:
1) The "Latency" test:

	a) To launch in oneshot mode:

		$ insmod /usr/realtime/modules/latency_rt.ko
		$ kern/latency/display

		Press Ctrl+C to stop the test when you have seen results.

		Then don't forget to unload latency module:

		$ rmmod latency_rt

		Here is an example of results (taken according to this README):

			$ insmod latency_rt.ko
			$ ../testsuite/kern/latency/display

			## RTAI latency calibration tool ##
			# period = 1000000 (ns)
			# avrgtime = 1 (s)
			# do not use the FPU
			# start the timer
			# timer_mode is oneshot

			RTAI Testsuite - KERNEL latency (all data in nanoseconds)
			RTH|    lat min|    ovl min|    lat avg|    lat max|    ovl max|   overruns
			RTD|     -35537|     -35537|     -29133|     -16250|     -16250|          0
			RTD|     -35537|     -35537|     -29085|     -12025|     -12025|          0
			RTD|     -35537|     -35537|     -29185|     -12800|     -12025|          0
			RTD|     -35537|     -35537|     -29080|       4950|       4950|          0
			RTD|     -35500|     -35537|     -29161|      -8987|       4950|          0
			RTD|     -35537|     -35537|     -29203|      -9050|       4950|          0
			RTD|     -35575|     -35575|     -29257|     -21725|       4950|          0
			RTD|     -35537|     -35575|     -29100|       1750|       4950|          0
			RTD|     -35537|     -35575|     -28930|      -8225|       4950|          0
			RTD|     -35537|     -35575|     -27618|       -362|       4950|          0
			RTD|     -35537|     -35575|     -29212|     -11412|       4950|          0
			RTD|     -35537|     -35575|     -29222|      -5575|       4950|          0
			RTD|     -35537|     -35575|     -29210|     -15450|       4950|          0
			RTD|     -35537|     -35575|     -29270|     -11325|       4950|          0
			RTD|     -35537|     -35575|     -29265|     -11325|       4950|          0
			RTD|     -35525|     -35575|     -29258|     -11350|       4950|          0
			RTD|     -35537|     -35575|     -29259|      -7725|       4950|          0
			RTD|     -35525|     -35575|     -29125|      -8325|       4950|          0
			RTD|     -35537|     -35575|     -29115|      -7537|       4950|          0
			RTD|     -35525|     -35575|     -29112|      -8100|       4950|          0
			^CRTD|     -35525|     -35575|     -29112|      -8100|       4950|          0
			$ rmmod latency_rt.ko


			CPU USE SUMMARY
			# 0 -> 26732
			END OF CPU USE SUMMARY


	b) To launch in periodic mode:
		Use the following kernel module parameter when loading 
		latency_rt:

		$ insmod /usr/realtime/modules/latency_rt.ko timer_mode=1

		Other steps are the same as in oneshot mode.

		Here is an example of results (taken according to this README):

			$ insmod latency_rt.ko timer_mode=1
			$ ../testsuite/kern/latency/display

			## RTAI latency calibration tool ##
			# period = 1000000 (ns)
			# avrgtime = 1 (s)
			# do not use the FPU
			# start the timer
			# timer_mode is periodic

			RTAI Testsuite - KERNEL latency (all data in nanoseconds)
			RTH|    lat min|    ovl min|    lat avg|    lat max|    ovl max|   overruns
			RTD|     -26225|     -26225|         -7|      26637|      26637|          0
			RTD|     -19425|     -26225|          4|      24325|      26637|          0
			RTD|     -21812|     -26225|         -7|      20900|      26637|          0
			RTD|     -21550|     -26225|          3|      19687|      26637|          0
			RTD|     -38675|     -38675|          3|      30888|      30888|          0
			RTD|     -25325|     -38675|         -3|      24375|      30888|          0
			RTD|     -21525|     -38675|         -6|      28500|      30888|          0
			RTD|     -24013|     -38675|         10|      30037|      30888|          0
			RTD|     -38100|     -38675|        -10|      28775|      30888|          0
			RTD|     -18075|     -38675|          0|      21600|      30888|          0
			RTD|     -18837|     -38675|          8|      31388|      31388|          0
			RTD|     -21162|     -38675|         -3|      30250|      31388|          0
			RTD|     -22500|     -38675|         -1|      22875|      31388|          0
			RTD|     -27825|     -38675|          5|      26850|      31388|          0
			RTD|     -34275|     -38675|         -2|      33750|      33750|          0
			RTD|     -23587|     -38675|         -6|      16150|      33750|          0
			RTD|     -24088|     -38675|          1|      23250|      33750|          0
			RTD|     -22200|     -38675|          4|      31112|      33750|          0
			RTD|     -20563|     -38675|          0|      13738|      33750|          0
			RTD|     -24700|     -38675|         -4|      25475|      33750|          0
			RTD|     -25613|     -38675|          2|      27225|      33750|          0
			RTH|    lat min|    ovl min|    lat avg|    lat max|    ovl max|   overruns
			RTD|     -14500|     -38675|          0|      21012|      33750|          0
			^CRTD|     -14500|     -38675|          0|      21012|      33750|          0
			$ rmmod latency_rt.ko


			CPU USE SUMMARY
			# 0 -> 27164
			END OF CPU USE SUMMARY


2) The "Preempt" test:

	$ insmod /usr/realtime/modules/preempt_rt.ko
	$ kern/preempt/display

        Press Ctrl+C to stop the test when you have seen results.

        Then don't forget to unload preempt_rt module:

        $ rmmod preempt_rt

	Here is an example of results (taken according to this README):

		$ insmod preempt_rt.ko
		$ ../testsuite/kern/preempt/display
		RTAI Testsuite - UP preempt (all data in nanoseconds)
		RTH|     lat min|     lat avg|     lat max|    jit fast|    jit slow
		RTD|      -34987|      -27951|       -8750|       84150|       82312
		RTD|      -35262|      -28023|       -8750|       84150|       82312
		RTD|      -35262|      -28024|       -3375|       84150|       82312
		RTD|      -35262|      -27922|       -3375|       84150|       88575
		RTD|      -35262|      -27932|       -3375|       84150|       88575
		RTD|      -35262|      -28037|       -3375|       84150|       88575
		RTD|      -35262|      -26817|        2987|       84150|       92513
		RTD|      -35262|      -27660|        2987|       84150|       92513
		RTD|      -35262|      -28090|        2987|       84150|       92513
		RTD|      -35262|      -27915|        2987|       84150|       92513
		RTD|      -35262|      -28104|        2987|       84150|       92513
		RTD|      -35262|      -28104|        2987|       84150|       92513
		RTD|      -35262|      -28076|        2987|       84150|       92513
		RTD|      -35262|      -28196|        2987|       84150|       92513
		RTD|      -35262|      -28019|        2987|       84150|       92513
		RTD|      -35262|      -28085|        2987|       84150|       92513
		RTD|      -35262|      -28079|        2987|       84150|       92513
		RTD|      -35262|      -28111|        2987|       89688|       92513
		RTD|      -35262|      -28127|        2987|       89688|       92513
		RTD|      -35262|      -28101|        2987|       89688|       92513
		^CRTD|      -35262|      -28101|        2987|       89688|       92513
		$ rmmod preempt_rt.ko


		CPU USE SUMMARY
		# 0 -> 35272
		END OF CPU USE SUMMARY


3) The "Switches" test:

        $ insmod /usr/realtime/modules/switches_rt.ko

	Results will be shown.

        $ rmmod switches_rt

	Here is an example of results (taken according to this README):

		$ insmod switches_rt.ko

		Wait for it ...


		FOR 10 TASKS: TIME 580 (ms), SUSP/RES SWITCHES 40000, SWITCH TIME 14513 (ns)

		FOR 10 TASKS: TIME 619 (ms), SEM SIG/WAIT SWITCHES 40000, SWITCH TIME 15494 (ns)

		FOR 10 TASKS: TIME 817 (ms), RPC/RCV-RET SWITCHES 40000, SWITCH TIME 20440 (ns)

		$ rmmod switches_rt.ko

		CPU USE SUMMARY
		# 0 -> 60011
		END OF CPU USE SUMMARY



To run the user-space tests:
1) The "Latency" test:

	$ cd user/latency
	$ ./latency&
	$ ./display

	Press ENTER to stop the test when you have 
	seen the results.

	Here is an example of results (taken according to this README):

		$ ./latency &

		## RTAI latency calibration tool ##
		# period = 1000000 (ns)            
		# average time = 1 (s)             
		# use the FPU                      
		# start the timer                  
		# timer_mode is oneshot            

		149
		$ ./display 
		RTAI Testsuite - USER latency (all data in nanoseconds)
		1970/01/1 00:10:47
		RTH|    lat min|    ovl min|    lat avg|    lat max|    ovl max|   overruns
		RTD|     -30012|     -30012|     -21930|       8987|       8987|          0
		RTD|     -29862|     -30012|     -21795|      10837|      10837|          0
		RTD|     -29900|     -30012|     -21467|      11012|      11012|          0
		RTD|     -30000|     -30012|     -19771|      34725|      34725|          0
		RTD|     -30087|     -30087|     -21494|      13212|      34725|          0
		RTD|     -29837|     -30087|     -21466|       6062|      34725|          0
		RTD|     -30037|     -30087|     -21552|      11962|      34725|          0
		RTD|     -29962|     -30087|     -21571|       1862|      34725|          0
		RTD|     -29512|     -30087|     -21517|       5375|      34725|          0
		RTD|     -29850|     -30087|     -21408|      13862|      34725|          0
		RTD|     -30025|     -30087|     -21617|       8000|      34725|          0
		RTD|     -30000|     -30087|     -21478|       8312|      34725|          0
		RTD|     -29962|     -30087|     -21395|       4700|      34725|          0
		RTD|     -29812|     -30087|     -21555|       8325|      34725|          0
		RTD|     -29912|     -30087|     -21510|       8037|      34725|          0
		RTD|     -29525|     -30087|     -21612|       5187|      34725|          0
		RTD|     -30062|     -30087|     -21501|       6762|      34725|          0
		RTD|     -29900|     -30087|     -21599|       2725|      34725|          0
		^CRTD|     -29900|     -30087|     -21599|       2725|      34725|          0

		>>> S = 98.696, EXECTIME = 0.18253


2) The "Preempt" test:

        $ cd user/preempt
        $ ./preempt&
        $ ./display

        Press Ctrl+C twice to stop the test when you have 
	seen the results and use "killall preempt" to terminate preempt test (is 
	required on some shells).

	Here is an example of results (taken according to this README):

		$ ./latency &

		## RTAI latency calibration tool ##
		# period = 1000000 (ns)            
		# average time = 1 (s)             
		# use the FPU                      
		# start the timer                  
		# timer_mode is oneshot            

		149
		$ ./display 
		RTAI Testsuite - USER latency (all data in nanoseconds)
		1970/01/1 00:10:47
		RTH|    lat min|    ovl min|    lat avg|    lat max|    ovl max|   overruns
		RTD|     -30012|     -30012|     -21930|       8987|       8987|          0
		RTD|     -29862|     -30012|     -21795|      10837|      10837|          0
		RTD|     -29900|     -30012|     -21467|      11012|      11012|          0
		RTD|     -30000|     -30012|     -19771|      34725|      34725|          0
		RTD|     -30087|     -30087|     -21494|      13212|      34725|          0
		RTD|     -29837|     -30087|     -21466|       6062|      34725|          0
		RTD|     -30037|     -30087|     -21552|      11962|      34725|          0
		RTD|     -29962|     -30087|     -21571|       1862|      34725|          0
		RTD|     -29512|     -30087|     -21517|       5375|      34725|          0
		RTD|     -29850|     -30087|     -21408|      13862|      34725|          0
		RTD|     -30025|     -30087|     -21617|       8000|      34725|          0
		RTD|     -30000|     -30087|     -21478|       8312|      34725|          0
		RTD|     -29962|     -30087|     -21395|       4700|      34725|          0
		RTD|     -29812|     -30087|     -21555|       8325|      34725|          0
		RTD|     -29912|     -30087|     -21510|       8037|      34725|          0
		RTD|     -29525|     -30087|     -21612|       5187|      34725|          0
		RTD|     -30062|     -30087|     -21501|       6762|      34725|          0
		RTD|     -29900|     -30087|     -21599|       2725|      34725|          0
		^CRTD|     -29900|     -30087|     -21599|       2725|      34725|          0

		>>> S = 98.696, EXECTIME = 0.18253


3) The "Switches" test:

        $ cd user/switches
        $ ./switches

	Results will be shown. Don't mention about warning for 
	rt_grow_and_lock_stack(). It's just our notice for RTAI users.

	Here is an example of results (taken according to this README):

		$ ./switches


		Wait for it ...


		FOR 10 TASKS: TIME 453 (ms), SUSP/RES SWITCHES 20000, SWITCH TIME 22687 (ns)

		FOR 10 TASKS: TIME 497 (ms), SEM SIG/WAIT SWITCHES 20000, SWITCH TIME 24860 (ns)

		FOR 10 TASKS: TIME 680 (ms), RPC/RCV-RET SWITCHES 20000, SWITCH TIME 34005 (ns)


*******************************************************************************
5. Support Information
*******************************************************************************

To order any additional information or to resolve arising problems 
contact 

Oleksandr Marchenko (Group Leader),

Laboratory for Embedded Computer Systems (LECS) 
of the Specialized Computer Systems Department 
of the National Technical University of Ukraine "KPI"
and
Innovation Business-Incubator "Polytechcenter" Ltd. - Freescale S3L Partner
37 Peremogy avenue, Kiev-03056, Ukraine
Tel:    +380 44 454-99-00
Email:  Oleksandr.Marchenko@lecs.com.ua 
        re085c@freescale.com


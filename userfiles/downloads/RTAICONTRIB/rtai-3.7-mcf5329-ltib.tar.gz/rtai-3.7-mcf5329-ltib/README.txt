*******************************************************************************

Real-Time Application Interface (version 3.7) to LinuxBSP integration manual 
for MCF5329EVB
README.txt
COPYRIGHT 2009 FREESCALE SEMICONDUCTOR, INC., ALL RIGHTS RESERVED

*******************************************************************************

FREESCALE SEMICONDUCTOR, INC.
ALL RIGHTS RESERVED
(c) Copyright 2009 Freescale Semiconductor, Inc.

*******************************************************************************

PURPOSE:   Provides manual to integrate RTAI to LinuxBSP for MCF5329EVB
AUTHORS: 	Oleksandr Marchenko	(Group Leader)
		Valentin Pavlyuchenko	(Project Leader)
		Mykola Lysenko 		(Lead Developer)

*******************************************************************************
1. Requirments
*******************************************************************************

MCF5329 evaluation board;
x86 compatible computer;
Linux operating system on the x86 computer;
Linux BSP for MCF5329EVB from 15/12/2008 installed in the system.

*******************************************************************************
2. Integration
*******************************************************************************

The product is supplied as a patch against the Linux BSP for MCF5329EVB and set
of patches against Linux kernel and RTAI distributions.
The following packages need to be downloaded:

Copy the following files included in this archive to the Local Package Pool 
(/opt/freescale/pkgs directory):

0069-ipipe-mcf5329_2.6.26.patch
0069-ipipe-mcf5329_2.6.26.patch.md5
rtai-3.7.tar.bz2
rtai-3.7.tar.bz2.md5
rtai-3.7_build.patch
rtai-3.7_build.patch.md5

Copy 'ltib-rtai-3.7-mcf5329.patch' file to the directory where ltib is 
installed.
Apply this patch:

$ patch -p1 < ltib-rtai-3.7-mcf5329.patch

Run ltib configuration script:

$ ./ltib -c

In the LTIB configuration window, set:
Configure the kernel = y
Package List->rtai = y

In the kernel configuration window, set:
Enable loadable module support = y
Enable loadable module support/Module unloading = y
Processor type and features->Interrupt Pipeline = y

Update devices:

$ ./ltib -p dev -f

After building has been completed, rtai modules and testsuite will be 
deployed in the rootfs.
To insert RTAI modules into the Linux kernel:
Run Linux on the board.

When shell console will appear, type:
$ cd /usr/realtime/modules
$ insmod rtai_hal.ko
$ insmod rtai_sched.ko
$ insmod rtai_msg.ko
$ insmod rtai_sem.ko
$ insmod rtai_fifos.ko
$ insmod rtai_mbx.ko


*******************************************************************************
3. Support information
*******************************************************************************

To order any additional information or to resolve arising problems 
contact Oleksandr Marchenko (Group Leader),
Laboratory for Embedded Computer Systems (LECS) 
of the Specialized Computer Systems Department 
of the National Technical University of Ukraine "KPI" 
and
Innovation Business-Incubator "Polytechcenter" Ltd. - Freescale S3L Partner
37 Peremogy avenue, Kiev-03056, Ukraine
Tel:    +380 44 454-99-00
Email:  Oleksandr.Marchenko@lecs.com.ua 
        re085c@freescale.com

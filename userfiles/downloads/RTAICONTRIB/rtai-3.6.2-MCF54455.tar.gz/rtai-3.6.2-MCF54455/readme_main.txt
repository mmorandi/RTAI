*******************************************************************************

This readme describes content of the Final Release Package
Version 1.1

readme_main.txt
COPYRIGHT 2008 FREESCALE SEMICONDUCTOR, INC., ALL RIGHTS RESERVED

*******************************************************************************

  FREESCALE SEMICONDUCTOR, INC.
  ALL RIGHTS RESERVED
  (c) Copyright 2008 Freescale Semiconductor, Inc.

*******************************************************************************

  PURPOSE:   Provides hard real-time scheduling functionality under
		Linux on the MCF54455 processor

  AUTHORS: 	Oleksandr Marchenko	(Group Leader)
		Igor Drozdynskyi	(Project Leader)
		Valentin Pavlyuchenko	(Developer)
		Mykola Lysenko 		(Developer)

*******************************************************************************

documentation/ - directory containing documentation;
documentation/RTAI_3.6.2_54455um.odt - User's Manual in ODT format;
documentation/RTAI_3.6.2_54455um.pdf - User's Manual in PDF format;
documentation/RTAI_MCF54455_Project_SPD_v4.doc - SPD document;
rtai-3.6.2/ - directory contatining RTAI for MCF54455 patches;
rtai-3.6.2/readme.txt - readme for building RTAI with Linux BSP;
rtai-3.6.2/lin2-6-23-m5445x-0049-I-Pipe.patch - patch for 2.6.23 kernel in LTIB;
rtai-3.6.2/ltib-rtai-3.6.2-m5445x.patch - patch for LTIB;
rtai-3.6.2/rtai-3.6.2.tar.bz2 - RTAI 3.6.2 distribution;
rtai-3.6.2/rtai-3.6.2-m68k.patch - patch for RTAI 3.6.2 in LTIB;
mp3play-rtai/ - directory containing demo project using RTAI;
mp3play-rtai/readme.txt - readme for demo project;
mp3play-rtai/ltib-mp3play.patch - patch for LTIB;
mp3play-rtai/mp3play-1.0-rtai.patch - patch for mp3play program to use 
				      RTAI facilities;
*.md5 - md5 sums of the corresponding files;

******************************************************************************
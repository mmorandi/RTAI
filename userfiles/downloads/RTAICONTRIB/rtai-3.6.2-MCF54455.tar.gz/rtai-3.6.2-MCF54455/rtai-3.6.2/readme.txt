*******************************************************************************

Real-Time Application Interface (version 3.6.2) for MCF54455

readme.txt
COPYRIGHT 2008 FREESCALE SEMICONDUCTOR, INC., ALL RIGHTS RESERVED

*******************************************************************************

  FREESCALE SEMICONDUCTOR, INC.
  ALL RIGHTS RESERVED
  (c) Copyright 2008 Freescale Semiconductor, Inc.

*******************************************************************************

  PURPOSE:   Provides hard real-time scheduling functionality under
		Linux on the MCF5445x processor

  AUTHORS: 	Oleksandr Marchenko	(Group Leader)
		Igor Drozdynskyi	(Project Leader)
		Valentin Pavlyuchenko	(Developer)
		Mykola Lysenko 		(Developer)

*******************************************************************************

This document contains information about the product.
The notes presented are the latest available.

The following topics are covered:

1. RTAI for MCF54455 project overview
2. Requirements
3. Installation
4. Testing RTAI
5. Support Information
6. Current project status
7. What's New
8. Troubleshooting
9. Last minute notes

*******************************************************************************
1. RTAI for MCF5445x project overview
*******************************************************************************

The Real-Time Application Interface (RTAI) is a set of extensions for the Linux
operating system that adds support for hard real-time scheduling for processes.
It is a real-time platform which allows for high predictability and low 
latency.

This project aims to implement support for RTAI (version 3.6.2) under Linux 
(kernel version 2.6.23) on the MCF5445x microcontroller. The work will consist 
of adding the architecture support code to RTAI as well as making the 
necessary changes to Linux kernel to enable RTAI support on the ColdFire 
architecture. 

*******************************************************************************
2. Requirements
*******************************************************************************

MCF54455 evaluation board;
x86 compatible computer;
Linux operating system on the x86 computer;
Linux BSP for M54455EVB installed in the system.

*******************************************************************************
3. Installation
*******************************************************************************

The product is supplied as a patch against the Linux BSP for M54455EVB and set
of patches against Linux kernel and RTAI distributions.

Copy the following files included in this archive to the Local Package Pool 
(/opt/freescale/pkgs directory):

rtai-3.6.2-m68k.patch
rtai-3.6.2-m68k.patch.md5
rtai-3.6.2.tar.bz2
rtai-3.6.2.tar.bz2.md5
lin2-6-23-m5445x-0049-I-Pipe.patch
lin2-6-23-m5445x-0049-I-Pipe.patch.md5

Copy 'ltib-rtai-3.6.2-m5445x.patch' file to the directory where ltib is 
installed.

Apply this patch:

$ patch -p1 < ltib-rtai-3.6.2-m5445x.patch

Run ltib configuration script:

$ ./ltib --configure

In the configuration window, set:
    Leave the sources after building = y
    Package list->rtai = y
If you want to configure RTAI, set:    
    Package List->RTAI->Configure RTAI at build time = y

NOTE: If you rebuilding kernel do not forget to rebuild RTAI after it.

After this command completes, rtai modules and testsuite will be deployed
in the rootfs.

To insert RTAI modules into the Linux kernel:
Run Linux on the board.
When shell console will appear, type:

# cd /usr/realtime/modules
# insmod rtai_hal.ko
# insmod rtai_sched.ko
# insmod rtai_sem.ko
# insmod rtai_fifos.ko
# insmod rtai_mbx.ko
# insmod rtai_tbx.ko
# insmod rtai_bits.ko
# insmod rtai_mq.ko
# insmod rtai_signal.ko

*******************************************************************************
4. Testing RTAI
*******************************************************************************

If you are running linux on NFS then you must create devices for accessing 
real-time FIFOs from user-space tasks:

# mknod /dev/rtf0 c 150 0
# mknod /dev/rtf1 c 150 1
# mknod /dev/rtf2 c 150 2
# mknod /dev/rtf3 c 150 3

RTAI Testsuite includes 6 tests:
1) Kernel-space tests:
   a) "latency"
   b) "switches"
   c) "preempt"
2) User-space tests:
   a) "latency"
   b) "switches"
   c) "preempt"

Testsuite has the following files:
.
`-- testsuite
    |-- kern
    |   |-- latency
    |   |   |-- latency_rt.ko
    |   |   |-- display
    |   |   `-- README
    |   |-- preempt
    |   |   |-- preempt_rt.ko
    |   |   |-- display
    |   |   `-- README
    |   `-- switches
    |       |-- switches_rt.ko
    |       `-- README
    `-- user
        |-- latency
        |   |-- latency
        |   |-- display
        |   `-- README
        |-- preempt
        |   |-- preempt
        |   |-- display
        |   `-- README
        `-- switches
            |-- switches
            `-- README

These files (except READMEs) with directory structure are copied to the 
'/usr/realtime' directory in rootfs during ltib deploy phase.

To launch tests:

Run Linux on the board.
When shell console will appear, type:

# cd /usr/realtime/modules
# insmod rtai_hal.ko
# insmod rtai_sched.ko
# insmod rtai_sem.ko
# insmod rtai_fifos.ko
# insmod rtai_mbx.ko
# insmod rtai_msg.ko
# cd ../testsuite

To run the kernel tests:
1) The "Latency" test:

	a) To launch in oneshot mode:

		# cd kern/latency
		# insmod latency_rt.ko
		# ./display

		Press Ctrl+C to stop the test when you have seen results.

		Then don't forget to unload latency module:

		# rmmod latency_rt

	b) To launch in periodic mode:
		Use the following kernel module parameter when loading 
		latency_rt:

		# insmod latency_rt.ko timer_mode=1

		Other steps are the same as in oneshot mode.

2) The "Preempt" test:

	# cd kern/preempt
	# insmod preempt_rt.ko
	# ./display

        Press Ctrl+C to stop the test when you have seen results.

        Then don't forget to unload preempt_rt module:

        # rmmod preempt_rt

3) The "Switches" test:

        # cd kern/switches
        # insmod switches_rt.ko

	Results will be shown.

        # rmmod switches_rt

To run the user-space tests:
1) The "Latency" test:

	a) To launch in oneshot mode:

        	$ cd user/latency
        	$ ./latency&
        	$ ./display

		Press Ctrl+C to stop the test when you have 
		seen the results.

	b) To launch in periodic mode:

		In RTAI in file <path-t-RTAI>/testsuite/user/latency/latency.c
		change the line 38 from
		
		#define TIMER_MODE  0

		to

		#define TIMER_MODE  1

		and perform all steps mentioned in a)

2) The "Preempt" test:

        $ cd user/preempt
        $ ./preempt&
        $ ./display

        Press Ctrl+C to stop the test when you have 
	seen the results.

3) The "Switches" test:

        $ cd user/switches
        $ ./switches

*******************************************************************************
5. Support Information
*******************************************************************************

To order any additional information or to resolve arising problems 
contact 

Oleksandr Marchenko (Group Leader),		

Laboratory for Embedded Computer Systems (LECS) 
of the Specialized Computer Systems Department 
of the National Technical University of Ukraine "KPI" 
and
Innovation Business-Incubator "Polytechcenter" Ltd. - Freescale S3L Partner
37 Peremogy avenue, Kiev-03056, Ukraine
Tel:    +380 44 454-99-00
Email:  Oleksandr.Marchenko@lecs.com.ua 
        re085c@freescale.com

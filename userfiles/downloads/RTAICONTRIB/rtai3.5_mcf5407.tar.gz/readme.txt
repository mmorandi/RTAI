*******************************************************************************

Real-Time Application Interface (version 3.5) for MCF5407

Version 1.0.1
readme.txt
COPYRIGHT 2007-2008 FREESCALE SEMICONDUCTOR, INC. , ALL RIGHTS RESERVED

*******************************************************************************

  FREESCALE SEMICONDUCTOR, INC.
  ALL RIGHTS RESERVED
  (c) Copyright 2007-2008 Freescale Semiconductor, Inc.

*******************************************************************************

  PURPOSE:   Provides hard real-time scheduling functionality under
		uClinux on the MCF5407 processor

  AUTHORS: 	Oleksandr Marchenko	(Group Leader)
		Valentin Pavlyuchenko	(Project Leader)
		Mykola Lysenko 		(Developer and Tester)
		Igor Drozdinsky 	(Developer and Tester)

*******************************************************************************

This document contains information about the product.
The notes presented are the latest available.

The following topics are covered:

1. RTAI for MCF5407 project overview
2. Requirements
3. Installation
4. Support Information
5. Current project status
6. What's New
7. Troubleshooting
8. Last minute notes

*******************************************************************************
1. RTAI for MCF5407 project overview
*******************************************************************************

The Real-Time Application Interface (RTAI) is a set of extensions for the Linux
operating system that adds support for hard real-time scheduling for processes.
It is a real-time platform which allows for high predictability and low 
latency.

This project aims to implement support for RTAI (version 3.5) under uClinux 
(kernel version 2.6.19) on the MCF5407 microcontroller. The work will consist 
of adding the architecture support code to RTAI as well as making the 
necessary changes to uClinux to enable RTAI support on the ColdFire 
architecture. 

*******************************************************************************
2. Requirements
*******************************************************************************

MCF5407 evaluation board;
x86 compatible computer;
Linux operating system on the x86 computer.

*******************************************************************************
3. Installation
*******************************************************************************

The product is supplied as a set of patches against the uClinux and RTAI
distributions. To use the product, the following packages need to be
downloaded:

- http://www.uclinux.org/pub/uClinux/dist/uClinux-dist-20070130.tar.bz2
- https://www.rtai.org/RTAI/rtai-3.5.tar.bz2
- http://www.uclinux.org/pub/uClinux/m68k-elf-tools/tools-20061214/m68k-uclinux-tools-20061214.sh

Run the m68k-uclinux-tools-20061214.sh script as root to install the cross
compilation tools.

Unzip the RTAI and uClinux archives to the same directory:

$ tar xjf uClinux-dist-20070130.tar.bz2
$ tar xjf rtai-3.5.tar.bz2

Copy the patches included in this archive to the current directory.

Apply the patches:

$ cd rtai-3.5
$ patch -p1 < ../rtai-mcf5407.patch
$ cd ../uClinux-dist
$ patch -p1 < ../uClinux-rtai-mcf5407.patch

Build uClinux:

$ cd uClinux-dist
$ make menuconfig

In the configuration window, set:
	Vendor/Product Selection->Vendor = Freescale
	Vendor/Product Selection->Freescale Products = M5407C3
	Kernel/Library/Defaults Selection->Kernel Version = linux-2.6.x
	Kernel/Library/Defaults Selection->libc Version = uClibc
	Kernel/Library/Defaults Selection->Customize Kernel Settings = y
	Kernel/Library/Defaults Selection->Customize Vendor/User Settings = y

In the kernel configuration window, set:
	Interrupt Pipeline = y
	Loadable module support/Enable loadable module support = y
	Loadable module support/Enable loadable module support/Module unloading = y

Then in user configuration options select things that you want to compile 
into romfs. You need to build insmod, rmmod, lsmod tools in order to use
RTAI:
	Busybox = y
	Busybox/insmod = y
	Busybox/insmod: lsmod = y
	Busybox/insmod: modprobe = y
	Busybox/insmod: rmmod = y
	Busybox/insmod: 2.6 and above kernel modules
Then exit from menuconfig with saving settings.

You may also want to build POSIX threading support (it must be enabled to 
compile some RTAI user-space testsuite modules - "preempt" and "switches").
To enable POSIX threading support configure uClibc:

$ cd uClibc
$ make menuconfig

In the configuration window, set:
	General Library Settings/POSIX Threading Support = y
	Networking Support/Remote Procedure Call (RPC) support = n

$ cd ..

$ make

After this command completes, there will be a file named image.bin in the 
images directory. Download this file to the board at offset 0x20000 and execute
it with the same starting address.
	
Build RTAI:

$ cd rtai-3.5
$ export EXTRA_CFLAGS="-Wa,-m5407 -m5407"
$ autoconf && automake
$ make ARCH=m68k LDFLAGS=-Wl,-elf2flt CROSS_COMPILE=m68k-uclinux- menuconfig

In the configuration window, set:
General->Linux Source Tree-><full-path-to-uclinux-dist>/linux-2.6.x

$ make

After this command completes, there will be following RTAI kernel modules 
(testsuite modules aren't shown):
.
 `-- base
     |-- arch
     |   |-- m68k
     |   |   `-- hal
     |   |       `-- rtai_hal.ko
     |-- ipc
     |   |-- bits
     |   |   `-- rtai_bits.ko
     |   |-- fifos
     |   |   `-- rtai_fifos.ko
     |   |-- mbx
     |   |   `-- rtai_mbx.ko
     |   |-- mq
     |   |   `-- rtai_mq.ko
     |   |-- msg
     |   |   `-- rtai_msg.ko
     |   |-- sem
     |   |   `-- rtai_sem.ko
     |   `-- tbx
     |       `-- rtai_tbx.ko
     |-- sched
     |   |-- rtai_lxrt.ko
     |   `-- rtai_sched.ko
     |-- tasklets
     |   |-- rtai_signal.ko
     |   `-- rtai_tasklets.ko
     |-- usi
     |   `-- rtai_usi.ko
     `-- wd
         `-- rtai_wd.ko

RTAI Testsuite includes 6 tests:
1) Kernel-space tests:
   a) "latency"
   b) "switches"
   c) "preempt"
2) User-space tests:
   a) "latency"
   b) "switches"
   c) "preempt"

Testsuite has the following files:
. 
 `-- testsuite
     |-- kern
     |   |-- latency
     |   |   |-- latency_rt.ko
     |   |   |-- display
     |   |   `-- README
     |   |-- preempt
     |   |   |-- preempt_rt.ko
     |   |   |-- display
     |   |   `-- README
     |   `-- switches
     |       |-- switches_rt.ko
     |       `-- README
     `-- user
         |-- latency
         |   |-- latency
         |   |-- display
         |   `-- README
         |-- preempt
         |   |-- preempt
         |   |-- display
         |   `-- README
         `-- switches
             |-- switches
             `-- README

To insert RTAI modules into the uClinux kernel:
$ cd uClinux-dist/romfs/
$ mkdir modules

Copy all modules to this '<path-to-uclinux>/romfs/modules' directory
and recompile uClinux.
Run uClinux on the board.
When Sash console will appear, type:

$ cd modules
$ insmod rtai_hal.ko
$ insmod rtai_sched.ko
$ insmod rtai_sem.ko
$ insmod rtai_fifos.ko
$ insmod rtai_mbk.ko
$ insmod rtai_tbk.ko
$ insmod rtai_bits.ko
$ insmod rtai_mfq.ko
$ insmod rtai_mq.ko
$ insmod rtai_signal.ko

To launch RTAI testsuite on the board:

$ cd uClinux-dist/romfs/
$ mkdir testsuite
$ mkdir modules

Copy tests you want to launch into '<path-to-uclinux>/romfs/testsuite' 
directory. 

Copy these modules to the '<path-to-uclinux>/romfs/modules' directory:
rtai_hal.ko
rtai_sched.ko
rtai_sem.ko
rtai_fifos.ko
rtai_mbx.ko
rtai_msg.ko

Create empty files with following names in the '<path-to-uclinux>/romfs/dev directory:

@rtf0,c,150,0
@rtf1,c,150,1
@rtf2,c,150,2
@rtf3,c,150,3

Recompile uClinux by typing 
$ make

Run uClinux on the board.
When Sash console will appear, type:

$ cd modules
$ insmod rtai_hal.ko
$ insmod rtai_sched.ko
$ insmod rtai_sem.ko
$ insmod rtai_fifos.ko
$ insmod rtai_mbx.ko
$ insmod rtai_msg.ko
$ cd ../testsuite

To run the kernel tests:
1) The "Latency" test:

	$ cd kern/latency
	$ insmod latency_rt.ko
	$ ./display

	Press Ctrl+C to stop the test when you have seen results.

	Then don't forget to unload latency module:

	$ rmmod latency

2) The "Preempt" test:

	$ cd kern/preempt
	$ insmod preempt_rt.ko
	$ ./display

        Press Ctrl+C to stop the test when you have seen results.

        Then don't forget to unload preempt_rt module:

        $ rmmod preempt_rt

3) The "Switches" test:

        $ cd kern/switches
        $ insmod switches_rt.ko

	Results will be shown.

        $ rmmod preempt_rt

To run the user-space tests:
1) The "Latency" test:

        $ cd user/latency
        $ ./latency&
        $ ./display

        Press Ctrl+C to stop the test when you have 
	seen the results.

2) The "Preempt" test:

        $ cd user/preempt
        $ ./preempt&
        $ ./display

        Press Ctrl+C to stop the test when you have 
	seen the results.

3) The "Switches" test:

        $ cd user/switches
        $ ./switches

        Results will be shown.

*******************************************************************************
4. Support Information
*******************************************************************************

To order any additional information or to resolve arising problems 
contact 

Oleksandr Marchenko (Group Leader),		

Laboratory for Embedded Computer Systems (LECS) 
of the Specialized Computer Systems Department 
of the National Technical University of Ukraine "KPI" 
and
Innovation Business-Incubator "Polytechcenter" Ltd. - Freescale S3L Partner
37 Peremogy avenue, Kiev-03056, Ukraine
Tel:    +380 44 454-99-00
Email:  Oleksandr.Marchenko@lecs.com.ua 
        re085c@freescale.com


*******************************************************************************
5. Current project status
*******************************************************************************

The port of RTAI itself to MCF5407 is complete.

*******************************************************************************
6. What's New
*******************************************************************************
version 1.0.1:

- All periods in tests were set to 1000000.
- Both latency tests were modified to start after 100 periods to prevent 
initial overruns.
- User manual was written.

version 1.0:

This is the release version. Everything seems to work. All tests succeded.

Now the user-space "switches" test works correctly.
Now the user-space "preempt" test works correctly.

Bug fixes:
- fixed bug of usage rt_grow_and_lock_stack() in user-space "switches" test that 
caused a hang when running the test.
- fixed bug in rtai_uvec_handler() that caused processing of RTAI syscalls with 
interrupts disabled.

version 0.8:

User-space part of RTAI now has correct signal handling, but some problems still exist. 
User-space is still under deep debugging.
Now the "latency" test works correctly.

Bug fixes:
- fixed the problem in signal handling that caused system hangs.
- fixed testsuite build system errors that caused incorrect linking of "preempt" 
    and "switches" user-space tests.

version 0.7:

Have a progress in user-space part of RTAI, but some problems still exist.
Kernel-space part is unchanged in this release.

Bug fixes:
- disabled update of task->unblocked value when processing signals in real-time.

version 0.6:

This is the alpha release of the patches for a port Linux RTAI version 3.5 
to uCLinux kernel version 2.6.19 for the MCF5407 processor.

Kernel-space interface works and now can be used for development.
User-space interface sometimes works incorrecty, so it shouldn't be used now.

Bug fixes:
- fixed a bug causing incorrect return values when calling start_rt_timer from user-space.
- introduced RTAI trap stack switching.
- fixed a bug with RTAI trap return values.
- improved IPIPE and RTAI acknowledging code.
- found a correct Sched Latency value.
- fixed a problem with local_irq_count.

version 0.5:

- fixed a bug with mach_tick.
- reorganized platform-depended code of interrupts handling in IPIPE.
- fixed a problem with UART's interrupt.
- reorganized code that uses rdtsc() function.
- fixed a bug connected with incorrect M68k gcc 4.1.1 assembly code
    generation in rt_task_wait_period() function.

version 0.4:

- Fixed timer counter reading bug in RTAI HAL.
- Fixed rt_printk RTAI bug.
- Fixed rtai_ulldiv division routine.
- Some minor fixes.

version 0.3:

- Finished porting all code to m68k platform. 
- Fixed some bugs in RTAI HAL, RTAI scheduler. 
- RTC (realtime clock) interface was removed from kernel.

version 0.2:

- HAL code was reorganized. (Interfaces haven't changed)
- Some changes in HAL code for support in m68k (unfinished for now).
- Bugfix in HAL interface.
- Updated RTAI atomic interface for code placed outside of kernel.
- Interface change (maybe temporary): rtai_u64div32c removed.
- Ported rtai_leds code.
- Unsupported interface removed from rtai_oldnames.h.
- Updated shared memory code.
- Ported IRQ part of IPIPE.
- Some changes in mcf5407 part of kernel code to include ipipe.
- Other (minor) updates in different places.

version 0.1:

This is the first version.

*******************************************************************************
7. Troubleshooting
*******************************************************************************
None

*******************************************************************************
8. Last minute notes
*******************************************************************************
None
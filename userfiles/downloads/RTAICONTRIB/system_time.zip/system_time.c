#define RT_GEN_TRUE                               1
#define RT_GEN_FALSE                              0

#define RT_GEN_SUCCESS                            1
#define RT_GEN_ERROR                             -1

#define RT_GEN_JD_1200UT_01_JAN_2000              2451545.0 /* Julian date at 12:00:00 UT, january 1st, 2000 A.D.*/
#define RT_GEN_JD_0000UT_01_JAN_1970              2440587.5 /* julian date at utc ref epoch Jan 1 (0:00:00), 1970 */

#define RT_GEN_TIME_CORR_MBX_KEY                  nam2num("RFTC") /*RFTC = RT GEN FUNC Time Correction*/

#define RT_GEN_ONE_NSEC                           1
#define RT_GEN_ONE_USEC                           (1E3*RT_GEN_ONE_NSEC)
#define RT_GEN_ONE_MSEC                           (1E3*RT_GEN_ONE_USEC)
#define RT_GEN_ONE_SEC                            (1E3*RT_GEN_ONE_MSEC)

#define RT_GEN_NUM_SEC_PER_MIN                    60
#define RT_GEN_NUM_MIN_PER_HOUR                   60
#define RT_GEN_NUM_SEC_PER_HOUR                   (RT_GEN_NUM_SEC_PER_MIN*RT_GEN_NUM_MIN_PER_HOUR)
#define RT_GEN_NUM_HOURS_PER_DAY                  24
#define RT_GEN_NUM_SEC_PER_DAY                    (RT_GEN_NUM_SEC_PER_HOUR*RT_GEN_NUM_HOURS_PER_DAY)

/*============================================================================================
get current system UTC time and ref_JD using a time correction term.
The correction is stored in a mail box area so all tasks calling this function will see
the time correction applied. The mail box is alloced at the first call. Thus 
a call to this function must take place at the end of task using free_corr_mbx=RT_GEN_TRUE
in order to dealloc it.
If a local time correction is required without sharing, then at first call just use free_corr_mbx=RT_GEN_TRUE
and the correction will be only seen by calling task.
Successs: RT_GEN_SUCCESS 
Error: RT_GEN_ERROR
Parameters:
unsigned long long int * date_nsec - number of nanoseconds elapsed since ref JD
long double * ref_JD - reference JD for date_nsec
long * nsec_corr - time correction in nanosec (When NULL, no correction)
int free_corr_mbx - command to free time correction mbx alloced at the first call
==============================================================================================*/
int rt_gen_func_get_system_time(unsigned long long int *  date_nsec, long double * ref_JD, long * nsec_corr, int free_corr_mbx)
{
  int ret = RT_GEN_SUCCESS;
  RTIME time_orig[2];  /*[counts, nanosec]*/  
  long double time_orig_JD = 0;/*JD for time_orig*/
  
  /*Remember static local variables declaration occur only at the first function call and then no more, 
  and that their value remain after function call terminates*/
  static int time_initialized = RT_GEN_FALSE;  
  static long long int time_orig_nsec=0;  
  static MBX * time_corr_nsec_mbx = NULL; /*time correction*/
  static int mbx_owner = RT_GEN_FALSE;
  static long int time_corr_nsec=0;
  static long double JD = RT_GEN_JD_1200UT_01_JAN_2000;/*ref JD for rt_gettimeorig*/

  if( (date_nsec != NULL) && (ref_JD != NULL) )
  {
    /*check if it is the first time we call the fucntion*/
    if(time_initialized == RT_GEN_FALSE)
    {
      /*Yes, it is. So initialize time origin and signalize initialization for future calls*/
      time_initialized = RT_GEN_TRUE;
      
      /*number of counts and nanoseconds elapsed since 00:00:00 on January 1, 1970, Coordinated Universal Time (UTC).*/
      rt_gettimeorig(time_orig);    

      /*get JD for time_orig*/      
      ret = rt_gen_func_convert_date_nsec_to_JD(&time_orig_JD, RT_GEN_JD_0000UT_01_JAN_1970, time_orig[1]);
    
      if(ret == RT_GEN_SUCCESS)
      {
        /*convert it to nanosec elapsed since JD2000*/
        ret = rt_gen_func_convert_JD_to_date_nsec(&time_orig_nsec, RT_GEN_JD_1200UT_01_JAN_2000, time_orig_JD);
        
        if(ret == RT_GEN_SUCCESS)
        {
          /*try to access time correction mbx*/
          time_corr_nsec_mbx = rt_get_adr(RT_GEN_TIME_CORR_MBX_KEY);
    
          if(time_corr_nsec_mbx == NULL)
          {
            /*No time correction mbx available, so create one*/
            time_corr_nsec_mbx = rt_mbx_init(RT_GEN_TIME_CORR_MBX_KEY,sizeof(long int));
    
            if(time_corr_nsec_mbx != NULL)
            {
              /*set as mbx owner*/
              mbx_owner = RT_GEN_TRUE;
            }
            else
            {
              fprintf(stderr,"rt_gen_func: fail allocating mbx for time correction in rt_gen_func_get_system_time!\n");
              ret = RT_GEN_ERROR;
            }  
          }
          
          if(time_corr_nsec_mbx != NULL)
          {
            /*set time correction*/
            ret = rt_mbx_ovrwr_send(time_corr_nsec_mbx, &time_corr_nsec, sizeof(long int));        
          
            if(ret < 0)
            {
              fprintf(stderr,"rt_gen_func: fail setting mbx data rt_gen_func_get_system_time!\n");
              ret = RT_GEN_ERROR;
            }  
          }
        }        
        else
        {
          fprintf(stderr,"rt_gen_func: fail converting time_orig wrt JD2000 in rt_gen_func_get_system_time!\n");
          ret = RT_GEN_ERROR;
        }  
      }
      else
      {
        fprintf(stderr,"rt_gen_func: fail converting time_orig to JD in rt_gen_func_get_system_time!\n");
        ret = RT_GEN_ERROR;
      }  
    }
    
    if(ret == RT_GEN_SUCCESS)
    {
      /*get reference JD*/
      *ref_JD = JD;

      /*check if it is mbx owner. Only the owner, who created the mbx, can delete it*/
      if(mbx_owner == RT_GEN_TRUE)
      {
        /*check if mbx shall be dealloced*/
        if(free_corr_mbx == RT_GEN_TRUE)
        {
          rt_mbx_delete(time_corr_nsec_mbx);
          time_corr_nsec_mbx = NULL;
        }
      }

      /*check if mbx still exists*/
      if(time_corr_nsec_mbx != NULL)      
      {
        /*check if time correction need update*/
        if(nsec_corr != NULL)
        {
          /*set time correction*/
          ret = rt_mbx_ovrwr_send(time_corr_nsec_mbx, nsec_corr, sizeof(long int));        
          
          if(ret < 0)
          {
            fprintf(stderr,"rt_gen_func: fail setting mbx data rt_gen_func_get_system_time!\n");
            ret = RT_GEN_ERROR;
          }  
        }
        
        if(ret == RT_GEN_SUCCESS)
        {
          /*get time correction*/
          rt_mbx_evdrp(time_corr_nsec_mbx, &time_corr_nsec , sizeof(long int));        
        }
      }
      else
      {        
        /*check if time correction need update*/
        if(nsec_corr != NULL)
        {
          /*get time correction*/
          time_corr_nsec = *nsec_corr;
        }
      }
      
      /*get number of nanosec since ref JD*/
      *date_nsec = (unsigned long long)(time_orig_nsec + rt_get_cpu_time_ns() + time_corr_nsec);
    }
  }
  else
  {
    fprintf(stderr,"rt_gen_func: NULL pointer in rt_gen_func_get_system_time! \n");
    ret = RT_GEN_ERROR;
  }      
  
  return ret;
}

/*============================================================================================
convert date in nsec elapsed since ref_JD to Julian date
Successs: RT_GEN_SUCCESS 
Error: RT_GEN_ERROR
Parameters:
long double * JD - julian date
long double ref_JD - reference julian date
unsigned long long int date_nsec - second since ref_JD
==============================================================================================*/
int rt_gen_func_convert_date_nsec_to_JD(long double * JD, long double ref_JD, unsigned long long int date_nsec)    
{
  int ret = RT_GEN_SUCCESS;
  long double date_nsec_d;  
  long double date_nsec_s;
         
  if(JD != NULL)
{
    /*date_nsec in seconds*/
    date_nsec_s = ((long double) date_nsec)/RT_GEN_ONE_SEC; 

    /*date_nsec in days*/
    date_nsec_d = date_nsec_s/RT_GEN_NUM_SEC_PER_DAY; 
    
    /*Calculate the Julian date by adding ref_JD*/
    *JD = date_nsec_d + ref_JD;    
}
  else
{
    fprintf(stderr,"rt_gen_func: NULL date pointer or invalid utc time in rt_gen_func_convert_date_nsec_to_JD! \n");
    ret = RT_GEN_ERROR;
}
  
  return ret;
}

/*============================================================================================
convert Julian date to date in nanosec elapsed since ref_JD
Successs: RT_GEN_SUCCESS 
Error: RT_GEN_ERROR
Parameters:
unsigned long long int * date_nsec - nanosecond since ref_JD
long double ref_JD - reference JD
long double JD - julian date
==============================================================================================*/
int rt_gen_func_convert_JD_to_date_nsec(unsigned long long int * date_nsec, long double ref_JD, long double JD)    
{
  int ret = RT_GEN_SUCCESS;
  long double date_nsec_d;  
  long double date_nsec_s;  
  
  if(date_nsec != NULL)
{
    /*Calculate date_nsec in days by subtracting the ref_JD*/
    date_nsec_d = JD - ref_JD;    

    /*date_nsec in seconds*/
    date_nsec_s = date_nsec_d*RT_GEN_NUM_SEC_PER_DAY;     
    
    /*date_nsec in nanosec*/
    *date_nsec = (unsigned long long) (date_nsec_s*RT_GEN_ONE_SEC);     
}
  else
{
    fprintf(stderr,"rt_gen_func: NULL date pointer or invalid utc time in rt_gen_func_convert_JD_to_date_nsec! \n");
    ret = RT_GEN_ERROR;
}
  
  return ret;
}
